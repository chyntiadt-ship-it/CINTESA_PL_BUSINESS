<?php
session_start();
include '../include/koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'penjual') {
    header("Location: ../auth/login.php");
    exit;
}

$id_penjual = (int) $_SESSION['id_user'];
$id_room = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id_room <= 0) {
    header("Location: pesan.php");
    exit;
}

// Pastikan kolom dibaca ada
$cek_kolom = mysqli_query($koneksi, "SHOW COLUMNS FROM pesan LIKE 'dibaca_pembeli'");
if (mysqli_num_rows($cek_kolom) == 0) {
    mysqli_query($koneksi, "ALTER TABLE pesan ADD COLUMN dibaca_pembeli TINYINT(1) NOT NULL DEFAULT 0");
}
$cek_kolom2 = mysqli_query($koneksi, "SHOW COLUMNS FROM pesan LIKE 'dibaca_penjual'");
if (mysqli_num_rows($cek_kolom2) == 0) {
    mysqli_query($koneksi, "ALTER TABLE pesan ADD COLUMN dibaca_penjual TINYINT(1) NOT NULL DEFAULT 0");
}

$query_room = mysqli_query($koneksi, "
    SELECT 
        chat.*,
        produk.nama_produk,
        produk.harga,
        user.username AS username_pembeli,
        user.nama_lengkap AS nama_pembeli
    FROM chat
    JOIN produk ON chat.id_produk = produk.id_produk
    JOIN user ON chat.id_pembeli = user.id_user
    WHERE chat.id_chat='$id_room'
    AND chat.id_penjual='$id_penjual'
    LIMIT 1
");

if (!$query_room || mysqli_num_rows($query_room) == 0) {
    echo "Pesan tidak ditemukan.";
    exit;
}

$data_room = mysqli_fetch_assoc($query_room);

// Tandai dibaca penjual
mysqli_query($koneksi, "
    UPDATE pesan
    SET dibaca_penjual = 1
    WHERE id_chat = '$id_room'
    AND id_pengirim <> '$id_penjual'
");

if (isset($_POST['kirim'])) {
    $isi_pesan = mysqli_real_escape_string($koneksi, trim($_POST['isi_pesan'] ?? ''));
    $foto_pesan = null;
    $file_pesan = null;

    if (isset($_FILES['gambar_kamera']) && $_FILES['gambar_kamera']['error'] === UPLOAD_ERR_OK) {
        $file_pesan = $_FILES['gambar_kamera'];
    } elseif (isset($_FILES['gambar_galeri']) && $_FILES['gambar_galeri']['error'] === UPLOAD_ERR_OK) {
        $file_pesan = $_FILES['gambar_galeri'];
    }

    if ($file_pesan !== null) {
        $ekstensi_valid = ['jpg', 'jpeg', 'png', 'webp'];
        $nama_file = $file_pesan['name'];
        $tmp_file = $file_pesan['tmp_name'];
        $ukuran_file = $file_pesan['size'];
        $ekstensi = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));

        if (!in_array($ekstensi, $ekstensi_valid)) {
            header("Location: detail_pesan.php?id=$id_room&pesan=foto_invalid");
            exit;
        }

        if ($ukuran_file > 5 * 1024 * 1024) {
            header("Location: detail_pesan.php?id=$id_room&pesan=foto_besar");
            exit;
        }

        if (!is_dir('../uploads/pesan')) {
            mkdir('../uploads/pesan', 0777, true);
        }

        $foto_pesan = 'pesan_' . $id_room . '_' . time() . '.' . $ekstensi;
        $lokasi_upload = '../uploads/pesan/' . $foto_pesan;

        if (!move_uploaded_file($tmp_file, $lokasi_upload)) {
            header("Location: detail_pesan.php?id=$id_room&pesan=foto_gagal");
            exit;
        }
    }

    if ($isi_pesan != "" || $foto_pesan != null) {
        if ($isi_pesan != "" && $foto_pesan != null) {
            $tipe_pesan = 'mixed';
        } elseif ($foto_pesan != null) {
            $tipe_pesan = 'image';
        } else {
            $tipe_pesan = 'text';
        }

        $foto_safe = $foto_pesan !== null ? "'" . mysqli_real_escape_string($koneksi, $foto_pesan) . "'" : "NULL";

        mysqli_query($koneksi, "
            INSERT INTO pesan (id_chat, id_pengirim, isi_pesan, foto_pesan, tipe_pesan, dibaca_pembeli, dibaca_penjual)
            VALUES ('$id_room', '$id_penjual', '$isi_pesan', $foto_safe, '$tipe_pesan', 0, 1)
        ");
    }

    header("Location: detail_pesan.php?id=$id_room");
    exit;
}

$query_pesan = mysqli_query($koneksi, "
    SELECT 
        pesan.*,
        user.username
    FROM pesan
    JOIN user ON pesan.id_pengirim = user.id_user
    WHERE pesan.id_chat='$id_room'
    ORDER BY pesan.tanggal_pesan ASC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Pesan - CINTESA</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../assets/css/base.css?v=1">
    <link rel="stylesheet" href="../assets/css/seller.css?v=4">
    <link rel="stylesheet" href="../assets/css/theme.css?v=10">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
</head>
<body class="seller-page pesan-page">

<header class="role-navbar">
    <a href="pesan.php" class="icon-button back-button" title="Kembali">
        <img src="../assets/icons/penjual/back-arrow.png" class="back-icon" alt="Kembali">
    </a>

    <a href="dashboard.php" class="brand-logo">CINTESA</a>

    <a href="../auth/logout.php" class="icon-button" title="Logout">
        <img src="../assets/icons/logout.png" alt="Logout">
    </a>
</header>

<main class="role-main message-main">
    <section class="message-card">
        <header class="message-header">
            <div class="seller-avatar">
                <?php echo strtoupper(substr($data_room['username_pembeli'], 0, 1)); ?>
            </div>

            <div class="message-info">
                <h1><?php echo htmlspecialchars($data_room['nama_pembeli'] ?: $data_room['username_pembeli']); ?></h1>
                <p>@<?php echo htmlspecialchars($data_room['username_pembeli']); ?></p>
                <span>Produk: <?php echo htmlspecialchars($data_room['nama_produk']); ?></span>
            </div>

            <div class="message-price">
                <small>Harga</small>
                <strong>Rp<?php echo number_format($data_room['harga'], 0, ',', '.'); ?></strong>
            </div>
        </header>

        <section class="security-note">
            <strong>Catatan Keamanan</strong>
            <p>
                Gunakan fitur pesan CINTESA untuk membahas stok, kondisi barang, nego harga, dan detail produk.
                Hindari transaksi di luar platform.
            </p>
        </section>

        <section class="message-body" id="pesanBody">
            <?php if ($query_pesan && mysqli_num_rows($query_pesan) > 0) { ?>
                <?php while ($row = mysqli_fetch_assoc($query_pesan)) { 
                    $is_me = ((int) $row['id_pengirim'] === $id_penjual);
                ?>
                    <div class="message-row <?php echo $is_me ? 'me' : 'buyer'; ?>">
                        <div class="message-bubble">
                            <?php if (!empty($row['foto_pesan'])) { ?>
                                <img 
                                    src="../uploads/pesan/<?php echo htmlspecialchars($row['foto_pesan']); ?>" 
                                    class="message-image"
                                    alt="Foto pesan"
                                >
                            <?php } ?>

                            <?php if (!empty($row['isi_pesan'])) { ?>
                                <p><?php echo nl2br(htmlspecialchars($row['isi_pesan'])); ?></p>
                            <?php } ?>

                            <small><?php echo date('d M Y, H:i', strtotime($row['tanggal_pesan'])); ?></small>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <div class="empty-box">
                    Belum ada pesan. Mulai balas pembeli dari kolom di bawah.
                </div>
            <?php } ?>
        </section>

        <form method="POST" enctype="multipart/form-data" class="message-input-form" id="pesanForm">
            <div class="attach-wrapper">
                <button type="button" class="attach-button" id="attachButton">+</button>
                
                <div class="attach-menu" id="attachMenu">
                    <label>
                        Ambil dari Galeri
                        <input type="file" name="gambar_galeri" id="galleryInput" accept="image/*" hidden>
                    </label>
                    
                    <label>
                        Ambil dari Kamera
                        <input type="file" name="gambar_kamera" id="cameraInput" accept="image/*" capture="environment" hidden>
                    </label>
                </div>
            </div>

            <textarea 
                name="isi_pesan" 
                id="replyTextarea" 
                rows="1" 
                placeholder="Tulis pesan..."
            ></textarea>

            <button type="submit" name="kirim" class="send-button">➤</button>

            <div class="file-preview" id="filePreview">
                <span id="fileName"></span>
                <button type="button" id="removeFile">×</button>
            </div>
        </form>
    </section>
</main>

<script src="../assets/js/global.js?v=10"></script>
</body>
</html>