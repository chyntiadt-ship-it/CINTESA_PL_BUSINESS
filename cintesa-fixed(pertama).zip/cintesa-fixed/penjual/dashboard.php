<?php
session_start();
include '../include/koneksi.php';
include '../include/pesan_helper.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'penjual') {
    header("Location: ../auth/login.php");
    exit;
}

$id_penjual = (int) $_SESSION['id_user'];
$username = $_SESSION['username'];

if (isset($_GET['hapus'])) {
    $id_produk = (int) $_GET['hapus'];

    mysqli_query($koneksi, "
        UPDATE produk
        SET status_produk='Dihapus'
        WHERE id_produk='$id_produk'
        AND id_user='$id_penjual'
    ");

    header("Location: dashboard.php?pesan=hapus_berhasil");
    exit;
}

$query_produk = mysqli_query($koneksi, "
    SELECT
        produk.*,
        kategori.nama_kategori,
        (
            SELECT produk_foto.foto
            FROM produk_foto
            WHERE produk_foto.id_produk = produk.id_produk
            ORDER BY produk_foto.id_foto ASC
            LIMIT 1
        ) AS foto_utama
    FROM produk
    LEFT JOIN kategori ON produk.id_kategori = kategori.id_kategori
    WHERE produk.id_user='$id_penjual'
    AND produk.status_produk='Tersedia'
    ORDER BY produk.id_produk DESC
");

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Penjual - CINTESA</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../assets/css/base.css?v=1">
    <link rel="stylesheet" href="../assets/css/seller.css?v=4">
    <link rel="stylesheet" href="../assets/css/theme.css?v=10">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
</head>
<body class="seller-page">

<header class="role-navbar">
    <a href="dashboard.php" class="brand-logo">CINTESA</a>

    <div class="seller-nav-actions">
        <a href="tambah_produk.php" class="icon-button dark" title="Tambah Produk">
            <img src="../assets/icons/penjual/add-product.png" alt="Tambah Produk">
        </a>

        <a href="pesan.php" class="icon-button" title="Pesan">
            <img src="../assets/icons/pesan.png" alt="Pesan">
        </a>

        <a href="../auth/logout.php" class="icon-button" title="Logout">
            <img src="../assets/icons/logout.png" alt="Logout">
        </a>
    </div>
</header>

<main class="role-main">
    <section class="page-heading center">
        <h1>Halo, <?php echo htmlspecialchars($username); ?></h1>
        <p>Ayo unggah produkmu, dan berjualanlah</p>
    </section>

    <?php if (isset($_GET['pesan']) && $_GET['pesan'] == 'hapus_berhasil') { ?>
        <div class="alert success">Produk berhasil disembunyikan.</div>
    <?php } ?>

    <section class="seller-product-grid">
        <?php if ($query_produk && mysqli_num_rows($query_produk) > 0) { ?>
            <?php while ($produk = mysqli_fetch_assoc($query_produk)) { ?>
                <article class="seller-product-card">
                    <div class="seller-product-image">
                        <?php
                        $foto_path = "../uploads/produk/" . ($produk['foto_utama'] ?? '');
                        if (!empty($produk['foto_utama']) && file_exists($foto_path)) {
                        ?>
                            <img src="<?php echo htmlspecialchars($foto_path); ?>" alt="Foto Produk">
                        <?php } else { ?>
                            <div class="no-image">Tidak ada foto</div>
                        <?php } ?>
                    </div>

                    <div class="seller-product-body">
                        <div class="product-top">
                            <span class="category">
                                <?php echo htmlspecialchars($produk['nama_kategori'] ?? 'Tanpa kategori'); ?>
                            </span>

                            <span class="status-pill">
                                <?php echo htmlspecialchars($produk['status_produk']); ?>
                            </span>
                        </div>

                        <h2><?php echo htmlspecialchars($produk['nama_produk']); ?></h2>

                        <p class="price">
                            Rp<?php echo number_format($produk['harga'], 0, ',', '.'); ?>
                        </p>

                        <p class="product-desc">
                            <?php echo htmlspecialchars(substr($produk['deskripsi'] ?? '', 0, 90)); ?>...
                        </p>

                        <div class="product-actions">
                            <a href="edit_produk.php?id=<?php echo $produk['id_produk']; ?>" class="main-button small">
                                Edit
                            </a>

                            <button
                                type="button"
                                class="delete-button open-delete-modal"
                                data-delete-url="dashboard.php?hapus=<?php echo $produk['id_produk']; ?>"
                            >
                                Hapus
                            </button>
                        </div>
                    </div>
                </article>
            <?php } ?>
        <?php } else { ?>
            <div class="empty-box">
                Belum ada produk. Klik tombol + di navbar untuk menambahkan produk pertama.
            </div>
        <?php } ?>
    </section>
</main>

<div class="modal-overlay" id="deleteModal">
    <div class="delete-modal">
        <h3>Hapus Produk?</h3>
        <p>Produk akan disembunyikan dari dashboard dan pembeli.</p>

        <div class="modal-actions">
            <button type="button" class="nav-button" id="cancelDelete">Batal</button>
            <a href="#" class="delete-button" id="confirmDelete">Hapus</a>
        </div>
    </div>
</div>

<script src="../assets/js/global.js?v=10"></script>
</body>
</html>
