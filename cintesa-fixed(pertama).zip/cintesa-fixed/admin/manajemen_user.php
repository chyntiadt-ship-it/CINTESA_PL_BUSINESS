<?php
session_start();
include '../include/koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$role = isset($_GET['role']) ? $_GET['role'] : 'semua';
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';

$where = "WHERE role IN ('pembeli', 'penjual')";

if ($role == 'pembeli' || $role == 'penjual') {
    $role_safe = mysqli_real_escape_string($koneksi, $role);
    $where .= " AND role = '$role_safe'";
}

if ($keyword != "") {
    $keyword_safe = mysqli_real_escape_string($koneksi, $keyword);
    $where .= " AND (
        nama_lengkap LIKE '%$keyword_safe%'
        OR username LIKE '%$keyword_safe%'
        OR email LIKE '%$keyword_safe%'
        OR nomor_telepon LIKE '%$keyword_safe%'
        OR role LIKE '%$keyword_safe%'
    )";
}

$query_user = mysqli_query($koneksi, "
    SELECT *
    FROM user
    $where
    ORDER BY id_user DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen User - CINTESA</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../assets/css/base.css?v=1">
    <link rel="stylesheet" href="../assets/css/admin.css?v=3">
    <link rel="stylesheet" href="../assets/css/theme.css?v=10">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
</head>
<body class="admin-page">

<header class="role-navbar">
    <a href="dashboard.php" class="icon-button back-button" title="Kembali">
        <img
            src="../assets/icons/penjual/back-arrow.png"
            class="back-icon"
            alt="Kembali"
        >
    </a>

    <a href="dashboard.php" class="brand-logo">CINTESA</a>

    <a href="../auth/logout.php" class="icon-button" title="Logout">
        <img src="../assets/icons/logout.png" alt="Logout">
    </a>
</header>

<main class="role-main">
    <section class="page-heading center">
        <h1>Manajemen User</h1>
        <p>Kelola data pembeli dan penjual di CINTESA.</p>
    </section>

    <section class="table-card">
        <div class="table-header">
            <div>
                <h2>Data User</h2>
                <p>Pilih role atau cari user berdasarkan nama, username, email, atau nomor telepon.</p>
            </div>

            <form method="GET" class="filter-form">
                <select name="role">
                    <option value="semua" <?php echo $role == 'semua' ? 'selected' : ''; ?>>Semua User</option>
                    <option value="penjual" <?php echo $role == 'penjual' ? 'selected' : ''; ?>>Penjual</option>
                    <option value="pembeli" <?php echo $role == 'pembeli' ? 'selected' : ''; ?>>Pembeli</option>
                </select>

                <input
                    type="text"
                    name="keyword"
                    placeholder="Cari user..."
                    value="<?php echo htmlspecialchars($keyword); ?>"
                >

                <button type="submit">Cari</button>
            </form>
        </div>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>No. Telepon</th>
                        <th>Role</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if ($query_user && mysqli_num_rows($query_user) > 0) { ?>
                        <?php $no = 1; while ($user = mysqli_fetch_assoc($query_user)) { ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($user['nama_lengkap']); ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['nomor_telepon'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($user['role']); ?></td>
                                <td><?php echo htmlspecialchars($user['status'] ?? 'aktif'); ?></td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="7" class="empty-row">Tidak ada data user.</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<script src="../assets/js/global.js?v=10"></script>
</body>
</html>
