<?php
session_start();
include '../include/koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] != 'pembeli') {
    header("Location: ../auth/login.php");
    exit;
}

$id_pembeli = (int) $_SESSION['id_user'];

if (isset($_GET['id_produk'])) {
    $id_produk = (int) $_GET['id_produk'];

    $query_produk = mysqli_query($koneksi, "
        SELECT * FROM produk
        WHERE id_produk='$id_produk'
        AND status_produk='Tersedia'
        LIMIT 1
    ");

    if (!$query_produk || mysqli_num_rows($query_produk) == 0) {
        echo "Produk tidak ditemukan atau sudah tidak tersedia.";
        exit;
    }

    $produk = mysqli_fetch_assoc($query_produk);
    $id_penjual = (int) $produk['id_user'];

    $cek_room = mysqli_query($koneksi, "
        SELECT * FROM chat
        WHERE id_produk='$id_produk'
        AND id_pembeli='$id_pembeli'
        AND id_penjual='$id_penjual'
        LIMIT 1
    ");

    if ($cek_room && mysqli_num_rows($cek_room) > 0) {
        $room = mysqli_fetch_assoc($cek_room);
        $id_room = (int) $room['id_chat'];
    } else {
        mysqli_query($koneksi, "
            INSERT INTO chat (id_produk, id_pembeli, id_penjual)
            VALUES ('$id_produk', '$id_pembeli', '$id_penjual')
        ");

        $id_room = mysqli_insert_id($koneksi);
    }

    header("Location: detail_pesan.php?id=$id_room");
    exit;
}

if (isset($_GET['id'])) {
    $id_room = (int) $_GET['id'];
    header("Location: detail_pesan.php?id=$id_room");
    exit;
}

$query_room_list = mysqli_query($koneksi, "
    SELECT
        chat.*,
        produk.nama_produk,
        produk.harga,
        produk.status_produk,
        user.username AS username_penjual,
        user.nama_lengkap AS nama_penjual,
        (
            SELECT isi_pesan
            FROM pesan
            WHERE pesan.id_chat = chat.id_chat
            ORDER BY pesan.id_pesan DESC
            LIMIT 1
        ) AS pesan_terakhir,
        (
            SELECT tanggal_pesan
            FROM pesan
            WHERE pesan.id_chat = chat.id_chat
            ORDER BY pesan.id_pesan DESC
            LIMIT 1
        ) AS tanggal_terakhir
    FROM chat
    JOIN produk ON chat.id_produk = produk.id_produk
    JOIN user ON chat.id_penjual = user.id_user
    WHERE chat.id_pembeli = '$id_pembeli'
    ORDER BY COALESCE(tanggal_terakhir, chat.tanggal_chat) DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pesan Pembeli - CINTESA</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../assets/css/base.css?v=1">
    <link rel="stylesheet" href="../assets/css/buyer.css?v=3">
    <link rel="stylesheet" href="../assets/css/theme.css?v=10">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
</head>
<body class="buyer-page">

<header class="role-navbar">
    <a href="dashboard.php" class="icon-button back-button" title="Kembali">
        <img src="../assets/icons/penjual/back-arrow.png" class="back-icon" alt="Kembali">
    </a>

    <a href="dashboard.php" class="brand-logo">CINTESA</a>

    <a href="../auth/logout.php" class="icon-button" title="Logout">
        <img src="../assets/icons/logout.png" alt="Logout">
    </a>
</header>

<main class="role-main">
    <section class="page-heading center">
        <h1>Pesan Saya</h1>
        <p>Daftar percakapan dengan penjual.</p>
    </section>

    <section class="message-list-card">
        <div class="table-header">
            <div>
                <h2>Daftar Pesan</h2>
                <p>Pilih salah satu percakapan untuk melanjutkan pesan.</p>
            </div>
        </div>

        <div class="conversation-list">
            <?php if ($query_room_list && mysqli_num_rows($query_room_list) > 0) { ?>
                <?php while ($room = mysqli_fetch_assoc($query_room_list)) { ?>
                    <article class="conversation-item">
                        <div class="seller-avatar">
                            <?php echo strtoupper(substr($room['username_penjual'], 0, 1)); ?>
                        </div>

                        <div class="conversation-content">
                            <h2><?php echo htmlspecialchars($room['nama_penjual'] ?: $room['username_penjual']); ?></h2>
                            <p>@<?php echo htmlspecialchars($room['username_penjual']); ?></p>
                            <span>Produk: <?php echo htmlspecialchars($room['nama_produk']); ?></span>
                            <small><?php echo htmlspecialchars($room['pesan_terakhir'] ?: 'Belum ada pesan.'); ?></small>
                        </div>

                        <div class="conversation-action">
                            <small>
                                <?php echo !empty($room['tanggal_terakhir']) ? date('d M Y, H:i', strtotime($room['tanggal_terakhir'])) : date('d M Y, H:i', strtotime($room['tanggal_chat'])); ?>
                            </small>
                            <a href="detail_pesan.php?id=<?php echo $room['id_chat']; ?>" class="main-button small">Buka Pesan</a>
                        </div>
                    </article>
                <?php } ?>
            <?php } else { ?>
                <div class="empty-box">Belum ada pesan. Buka detail produk lalu pilih Tanya Penjual.</div>
            <?php } ?>
        </div>
    </section>
</main>

<script src="../assets/js/global.js?v=10"></script>
</body>
</html>
