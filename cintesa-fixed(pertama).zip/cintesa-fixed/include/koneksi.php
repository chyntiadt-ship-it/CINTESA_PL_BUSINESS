<?php
$host = "localhost";
$user = "syrbffus_cintesa";
$password = "{ni!j&VZSufVD~SL";
$database = "syrbffus_pree_love";

$koneksi = mysqli_connect($host, $user, $password, $database);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>